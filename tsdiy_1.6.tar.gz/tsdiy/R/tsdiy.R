
arp <- function (e, a, init = rep(mu, p), mu = 0) {
  n <- length(e)
  p <- length(a)
  if(min(Mod(polyroot(c(1, -a)))) <= 1) {
    stop("该AR过程非平稳！")
  }
  if (length(init) != p) {
    stop("初值的个数和AR的阶数不一致！")
  }
  theta <- (1 - sum(a)) * mu
  x <- c(init, rep(0, n))
  e <- c(rep(0, p), e)
  fill.index <- (p + 1):(p + n)
  for (t in fill.index) {
    x[t] <- theta + sum(a * x[(t - 1):(t - p)]) + e[t]
  }
  return(x[fill.index])
}

rwd <- function (e, d = 1, init = rep(0, d), theta = 0) {
  n <- length(e)
  if (length(init) != d) {
    stop("初值的个数和差分的阶数不一致！")
  }
  a <- (-1) ^ (0:(d - 1)) * choose(d, 1:d)
  x <- c(init, rep(0, n))
  e <- c(rep(0, d), e)
  fill.index <- (d + 1):(n + d)
  for (t in fill.index) {
    x[t] <- theta + sum(a * x[(t - 1):(t - d)]) + e[t]
  }
  return(x[fill.index])
}

maq <- function (e, b, init = rep(0, q), mu = 0) {
  n <- length(e)
  q <- length(b)
  if (length(init) != q) {
    stop("初值的个数和MA的阶数不一致！")
  }
  x <- c(init, rep(0, n))
  e <- c(rep(0, q), e)
  fill.index <- (q + 1):(n + q)
  for (t in fill.index) {
    x[t] <- mu + e[t] + sum(b * e[(t - 1):(t - q)])
  }
  return(x[fill.index])
}

SACF <- function (x, lag.max = 5, plot = TRUE) {
  n <- length(x)
  if (lag.max > n / 2) {
    stop("不建议lag.max超过序列长度的1/2.")
  }
  x.bar <- mean(x, na.rm = TRUE)
  x0 <- c(x) - x.bar
  rho.hat <- rep(0, lag.max)
  fenmu <- sum(x0 ^ 2, na.rm = TRUE)
  for (k in 1:lag.max) {
    fenzi <- sum(head(x0, n - k) * tail(x0, n - k), na.rm = TRUE)
    rho.hat[k] <- fenzi / fenmu
  }
  if (plot) {
    barlett <- c(-1, 1) * (1.96 / sqrt(n))
    lags.show <- 0:lag.max
    if (is.ts(x) && frequency(x) > 1) {
      lags.show <- lags.show / frequency(x)
    }
    plot(lags.show, c(1, rho.hat), type = "h", ylim = range(1, rho.hat, barlett),
         xlab = "滞后阶数", ylab = "样本自相关系数")
    abline(h = barlett, lty = 2, col = "blue")
    abline(h = 0)
  }
  return(rho.hat)
}

LB <- function (x, lag.max = 5, plot = TRUE) {
  if (anyNA(x)) {
    stop("x存在缺失值！先填补缺失值！")
  }
  pval <- rep(0, lag.max)
  for (k in 1:lag.max) {
    pval[k] <- Box.test(x, lag = k, type = "Ljung-Box")$p.value
  }
  if (plot) {
    plot(1:lag.max, pval, ylim = c(0, 1), xlab = "滞后阶数", ylab = "P值")
    abline(h = 0.05, lty = 2, col = "blue")
  }
  return(pval)
}

ADF <- function (x, type = 2, LB.lag = 5) {
  if (anyNA(x)) {
    stop("x存在缺失值！先填补缺失值！")
  }
  if (LB.lag > length(x) / 2) {
    stop("不建议LB.lag超过序列长度的1/2.")
  }
  p.max <- ceiling(0.4 * length(x)); ok <- FALSE
  for (p in 1:p.max) {
    adf <- urca::ur.df(x, type = c("none", "drift", "trend")[type], lags = p - 1)
    pval <- LB(adf@res, LB.lag, plot = FALSE)
    if (min(pval) > 0.05) {
      ok <- TRUE
      break
    }
  }
  if (ok) {
    tau <- adf@teststat[1]
    cval <- adf@cval[1, ]
    message(sprintf("基于AR(%d)表示的第%d类ADF单位根检验结果", p, type))
  } else {
    tau <- NA; cval[] <- NA
    message(sprintf("在所有可行的AR阶数上都未能获得可信的检验结果"))
  }
  return(c(tau = tau, cval))
}


ARIMA <- function (x, pdq = c(0, 0, 0), PDQ = c(0, 0, 0), s = NA, include.drift = TRUE, reg = NULL) {
  xx <- x; xreg <- reg
  if (length(pdq) != 3) {
    stop("参数pdq需要提供p、d、q三个值！")
  }
  if (is.na(s)) {
    if (sum(PDQ) > 0) {
      warning("频率未知，将忽略季节成分！")
      PDQ <- c(0, 0, 0)
    }
  } else {
    if (s < 4) {
      stop("有意义的频率至少应为4！")
    }
    if (length(PDQ) != 3) {
      stop("参数PDQ需要提供P、D、Q三个值！")
    }
    if (sum(PDQ) == 0) {
      warning("季节成分未知，将忽略频率！")
      s <- NA
    }
  }
  if (!is.null(xreg)) {
    xreg <- as.matrix(xreg)
    if (!is.numeric(xreg)) {
      stop("reg无法被整理为数值矩阵！")
    }
    if (nrow(xreg) != length(xx)) {
      stop("reg的长度或行数与x的长度不一致！")
    }
  }
  d <- pdq[2]
  if (d > 2) {
    stop("一阶差分次数不应多于2次！")
  }
  if (d > 0) {
    xx <- diff(xx, differences = d)
    if (!is.null(xreg)) {
      xreg <- diff(xreg, differences = d)
    }
  }
  D <- PDQ[2]
  if (D > 1) {
    stop("季节差分次数不应多于1次！")
  }
  if (D > 0) {
    xx <- diff(xx, lag = s, differences = D)
    if (!is.null(xreg)) {
      xreg <- diff(xreg, lag = s, differences = D)
    }
  }
  n <- length(xx)
  if ((d + D) > 1) {
    include.drift <- FALSE
  }
  pdq[2] <- PDQ[2] <- 0
  fit <- try(arima(xx, order = pdq, seasonal = list(order = PDQ, period = s), include.mean = include.drift, xreg = xreg), silent = TRUE)
  if (inherits(fit, "try-error")) {
    fit <- arima(xx, order = pdq, seasonal = list(order = PDQ, period = s), include.mean = include.drift, xreg = xreg, method = "ML")
  }
  r <- fit$residuals
  sigma <- sqrt(fit$sigma2)
  est <- fit$coef
  se <- sqrt(diag(fit$var.coef))
  pval <- round(2 * pnorm(abs(est) / se, lower.tail = FALSE), 3)
  K <- sum(pdq) + sum(PDQ) + include.drift + 1
  aic <- -2 * fit$loglik + 2 * K
  aicc <- -2 * fit$loglik + 2 * K * (n / (n - K - 1))
  bic <- -2 * fit$loglik + log(n) * K
  coef <- rbind(est, se, pval)
  if (include.drift) colnames(coef)[K - 1] <- "drift"
  ic <- c(AIC = aic, AICc = aicc, BIC = bic)
  m <- cumsum(c(0, pdq[-2], PDQ[-2]))
  lam <- vector("list", 4); names(lam) <- c("ar", "ma", "sar", "sma")
  for (i in 1:4) {
    if (m[i] < m[i + 1]) {
      abAB <- est[seq(m[i] + 1, m[i + 1])]
      pc.B <- c(1, (-1) ^ i * abAB)
      pc.lam <- rev(pc.B)
      lam[[i]] <- polyroot0(pc.lam)
    }
  }
  lam <- lam[lengths(lam) > 0]
  ar.pc <- ma.pc <- sar.pc <- sma.pc <- 1
  if (pdq[1] > 0) ar.pc <- c(ar.pc, -est[(m[1] + 1):m[2]])
  if (pdq[3] > 0) ma.pc <- c(ma.pc, est[(m[2] + 1):m[3]])
  if (PDQ[1] > 0) sar.pc <- c(sar.pc, rbind(matrix(0, nrow = s - 1, ncol = PDQ[1]), -est[(m[3] + 1):m[4]]))
  if (PDQ[3] > 0) sma.pc <- c(sma.pc, rbind(matrix(0, nrow = s - 1, ncol = PDQ[3]), est[(m[4] + 1):m[5]]))
  a <- (-1) * polyprod(ar.pc, sar.pc)[-1]
  b <- polyprod(ma.pc, sma.pc)[-1]
  theta <- 0; if (include.drift) theta <- est[[m[5] + 1]]
  s0 <- if(is.na(s)) 0 else s
  boot <- list(d = d, D = D, s = s, a = a, b = b, theta = theta,
               x = tail(x, length(a) + d + D * s0), reg = tail(reg, d + D * s0))
  structure(list(residuals = r, coef = t(coef), lambda = lam, ic = ic, bootstrap = boot), class = "ARIMAdiy")
}

MAfilter <- function (x, k) {
  if (k %% 2 == 1) {
    w <- rep(1 / k, k)
  } else {
    w <- rep(1 / k, k + 1)
    w[1] <- w[k + 1] <- 1 / (2 * k)
    k <- k + 1
  }
  n <- length(x)
  y <- rep(NA, n)
  n.na <- (k - 1) / 2
  for (i in 1:(n - k + 1)) {
    x.seg <- x[i:(k + i - 1)]
    if (anyNA(x.seg)) {
      valid.index <- !is.na(x.seg)
      w.valid <- w[valid.index]
      x.seg.valid <- x.seg[valid.index]
      w.valid <- w.valid / sum(w.valid)
      average <- sum(w.valid * x.seg.valid)
    } else {
      average <- sum(w * x.seg)
    }
    y[n.na + i] <- average
  }
  r <- x - y
  ans <- list(trend = y, remainder = r)
  return(ans)
}


tsdf <- function (tm, x, interval) {
  if (!is.numeric(x)) {
    stop("x输入不是数值！先确保它不是字符串！")
  }
  if (anyNA(tm)) {
    stop("tm包含缺失值！")
  }
  if (interval == "year") {
    if (!is.numeric(tm)) {
      stop("tm不是数值年份！")
    }
    tm <- as.integer(tm)
    index <- order(tm)
    tm <- tm[index]
    x <- x[index]
    cy <- tm - tm[1] + 1L
    nx <- length(cy); n <- cy[nx]
    if (n > nx) {
      tm <- seq.int(tm[1], by = 1L, length.out = n)
      x.padded <- rep(NA, n); x.padded[cy] <- x; x <- x.padded
    }
    dat <- data.frame(year = tm, x = x)
  }
  else {
    is.POSIXt <- inherits(tm, "POSIXt")
    is.Date <- inherits(tm, "Date")
    if (!(is.POSIXt || is.Date)) {
      stop("tm不是日期/时间！先用lubridate做转化！")
    }
    tm <- as.POSIXlt(tm)
    index <- order(tm)
    tm <- tm[index]
    x <- x[index]
    if (interval == "quarter") {
      year <- tm$year + 1900L
      month <- tm$mon + 1L
      qtr <- as.integer(ceiling(month / 3))
      cq <- 4L * (year - year[1]) + qtr
      nx <- length(cq)
      n <- cq[nx] - cq[1] + 1L
      if (n > nx) {
        cq.padded <- cq[1]:cq[nx]
        x.padded <- rep(NA, n)
        x.padded[cq - cq[1] + 1L] <- x
        x <- x.padded
        year <- (cq.padded - 1L) %/% 4L + year[1]
        qtr <- (cq.padded - 1L) %% 4L + 1L
      }
      yq <- sprintf("%4d-Q%1d", year, qtr)
      dat <- data.frame(yq = yq, year = year, quarter = qtr, x = x)
    }
    else if (interval == "month") {
      year <- tm$year + 1900L
      month <- tm$mon + 1L
      cm <- 12L * (year - year[1]) + month
      nx <- length(cm)
      n <- cm[nx] - cm[1] + 1L
      if (n > nx) {
        cm.padded <- cm[1]:cm[nx]
        x.padded <- rep(NA, n)
        x.padded[cm - cm[1] + 1L] <- x
        x <- x.padded
        year <- (cm.padded - 1L) %/% 12L + year[1]
        month <- (cm.padded - 1L) %% 12L + 1L
      }
      ym <- sprintf("%4d-%02d", year, month)
      dat <- data.frame(ym = ym, year = year, month = month, x = x)
    }
    else if (interval == "day") {
      dt <- as.Date(tm)
      cd <- unclass(dt); cd <- cd - cd[1] + 1L
      nx <- length(cd); n <- cd[nx]
      if (n > nx) {
        dt <- as.Date(seq.int(unclass(dt[1]), by = 1L, length = n))
        x.padded <- rep(NA, n); x.padded[cd] <- x; x <- x.padded
        tm <- as.POSIXlt(dt)
      }
      year <- tm$year + 1900
      month <- tm$mon + 1
      yday <- tm$yday + 1
      wday <- tm$wday; wday[wday == 0] <- 7
      ym <- format(dt, format = "%Y-%m")
      ymd <- format(dt, format = "%Y-%m-%d")
      dat <- data.frame(ymd = ymd, ym = ym, year = year, month = month,
                        yday = yday, wday = wday, x = x)
    }
    else if (interval == "hour") {
      year <- tm$year + 1900
      month <- tm$mon + 1
      yday <- tm$yday + 1
      wday <- tm$wday; wday[wday == 0] <- 7
      hour <- tm$hour
      ym <- format(tm, format = "%Y-%m")
      ymd <- format(tm, format = "%Y-%m-%d")
      dat <- data.frame(ymd = ymd, ym = ym, year = year, month = month,
                        yday = yday, wday = wday, hour = hour, x = x)
    }
    else {
      stop("未知interval值！")
    }
  }
  dat
}

polyprod <- function (f, g) {
  m <- tcrossprod(f, g)
  h <- split(m, row(m) + col(m))
  unlist(lapply(h, sum), use.names = FALSE)
}

rwDs <- function (e, D = 1, s, init = rep(0, D * s), theta = 0) {
  if (missing(s)) {
    stop("请提供频率！")
  }
  if (s < 4) {
    stop("有意义的频率至少应为4！")
  }
  n <- length(e)
  if (length(init) != D * s) {
    stop("初值的个数须为差分阶数的s倍！")
  }
  a <- (-1) ^ (0:(D - 1)) * choose(D, 1:D)
  n.padded <- ceiling(n / s) * s - n
  x <- c(init, rep(0, n + n.padded))
  e <- c(rep(0, D * s), e, numeric(n.padded))
  x <- matrix(x, nrow = s)
  e <- matrix(e, nrow = s)
  fill.index <- (D + 1):(ceiling(n / s) + D)
  for (t in fill.index) {
    x[, t] <- theta + rowSums(a * x[, (t - 1):(t - D), drop = FALSE]) + e[, t]
  }
  x <- x[, fill.index]
  return(x[1:n])
}


season <- function (x) {
  if (!is.ts(x)) {
    stop("x不是一个ts类型的时间序列！")
  }
  tp <- c(time(x))
  ind <- frequency(x) * (tp - floor(tp)) + 1
  as.integer(round(ind))
}

ADFs <- function (x, type = 2, LB.lag = 5) {
  if (!is.ts(x)) {
    stop("x不是一个ts类型的时间序列！")
  }
  f <- frequency(x)
  if (f != 4 && f != 12) {
    stop("季节ADF检验只适用于季频或月频数据！")
  }
  if (anyNA(x)) {
    stop("x存在缺失值！先填补缺失值！")
  }
  sind <- season(x)
  xx <- split(c(x), sind)
  n <- min(lengths(xx))
  n.5 <- floor(0.5 * n)
  if (LB.lag > n.5) {
    stop(sprintf("只有%d年的数据，不建议LB.lag超过其一半！", n))
  }
  ans <- vector("list", length(xx))
  for (i in 1:length(xx)) {
    ans[[i]] <- suppressMessages(ADF(xx[[i]], type, LB.lag))
  }
  ans <- do.call(rbind, ans)
  if (f == 12) rownames(ans) <- month.abb
  else rownames(ans) <- paste0("Qtr", 1:4)
  ans
}

polyroot0 <- function (z, tol = 1e-10) {
  x <- polyroot(z)
  m <- Mod(x); r <- Re(x); i <- Im(x)
  r[abs(r) < m * tol] <- 0
  i[abs(i) < m * tol] <- 0
  complex(real = r, imaginary = i)
}


mDaniell <- function (r, layers, plot = TRUE) {
  ker <- kernel("modified.daniell", rep(r, layers))
  if (plot) plot(ker)
  ker
}

DomiPeriod <- function (x, plot = TRUE) {
  est <- spec.pgram(x, span = rep(3, 5), plot = FALSE)
  freq <- est$freq
  spec <- est$spec
  id.peak <- which.max(spec)
  if (plot) {
    plot(freq, log(spec), type = "l", xlab = "频率", ylab = "对数谱密度")
    points(freq[id.peak], log(spec[id.peak]), pch = 20)
  }
  if (id.peak > 1) 1 / freq[id.peak] else NA
}


ForecastARIMA <- function (model, n.ahead, new.reg = NULL) {
  if (!inherits(model, "ARIMAdiy")) {
    stop("缺少一个由tsdiy::ARIMA返回的model！")
  }
  d <- model$bootstrap$d
  D <- model$bootstrap$D
  s <- model$bootstrap$s; if (is.na(s)) s <- 0
  p <- length(a <- model$bootstrap$a)
  q <- length(b <- model$bootstrap$b)
  theta <- model$bootstrap$theta
  reg <- model$bootstrap$reg
  if (!is.null(reg)) {
    stop("暂不支持带回归变量的ARIMA模型！")
    reg <- as.matrix(reg)
  }
  x.boot <- sample(model$residuals, size = n.ahead, replace = TRUE)
  if (q > 0) {
    init <- tail(model$residuals, q)
    x.boot <- maq(e = x.boot, b = b, init = init, mu = 0)
  }
  if (p > 0) {
    init <- model$bootstrap$x
    if (D > 0) init <- diff(init, lag = s, differences = D)
    if (d > 0) init <- diff(init, differences = d)
    if (theta != 0) init <- init - theta
    x.boot <- arp(e = x.boot, a = a, init = init, mu = 0)
  }
  if (d == 0 && D == 0) {
    x.boot <- x.boot + theta
  }
  if (d == 1 && D == 0) {
    x.boot <- rwd(e = x.boot, d = 1, init = tail(x, 1), theta = theta)
  }
  if (d == 0 && D == 1) {
    x.boot <- rwDs(e = x.boot, D = 1, s = s, init = tail(x, s), theta = theta)
  }
  if (d + D > 1) {
    if (d > 0) {
      init <- tail(x, d + D * s)
      if (D > 0) init <- diff(init, lag = s, differences = D)
      x.boot <- rwd(e = x.boot, d = d, init = init, theta = 0)
    }
    if (D > 0) {
      x.boot <- rwDs(e = x.boot, D = D, s = s, init = tail(x, D * s), theta = 0)
    }
  }
  x.boot
}

BootstrapTS <- function (x, model) {
  if (inherits(model, "ARIMAdiy")) {
    d <- model$bootstrap$d
    D <- model$bootstrap$D
    s <- model$bootstrap$s; if (is.na(s)) s <- 0
    r <- c(model$residuals)
    f <- x - c(numeric(d + D * s), r)
    r.boot <- sample(r, size = length(r), replace = TRUE)
    r.boot <- c(numeric(d + D * s), r.boot)
    return(f + r.boot)
  }
  if (inherits(model, "HoltWinters")) {
    f <- c(model$fitted[, 1])
    r <- tail(x, length(f)) - f
    r.boot <- sample(r, size = length(r), replace = TRUE)
    n0 <- length(x) - length(r)
    r <- c(numeric(n0), r)
    r.boot <- c(numeric(n0), r.boot)
    return(x - r + r.boot)
  }
  stop("model是未知的模型类型！")
}

gpow <- function (x, alpha, inverse = FALSE) {
  if (!inverse) {
    sign(x) * abs(x) ^ alpha
  } else {
    sign(x) * abs(x) ^ (1 / alpha)
  }
}


glog <- function (x, alpha = 1, inverse = FALSE) {
  if (!inverse) {
    sign(x) * log(alpha * abs(x) + 1)
  } else {
    sign(x) * (1 / alpha) * (exp(abs(x)) - 1)
  }
}

boxcox <- function (x, lambda, inverse = FALSE) {
  if (!inverse) {
    if (any(x[!is.na(x)] <= 0)) stop("x的值不全为正数！")
    if (lambda == 0) log(x) else (1 / lambda) * (x ^ lambda - 1)
  } else {
    if (lambda == 0) exp(x) else (1 + lambda * x) ^ (1 / lambda)
  }
}


